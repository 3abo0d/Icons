package com.glassicons;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.View;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Glass Icons v0.3 - for a SELECTED list of apps, replaces the icon drawing with a glass tile
 * (blurred wallpaper slice + app-colour tint + rim light + sheen) carrying only the app's own
 * adaptive-icon foreground (the symbol). All other apps are untouched.
 *
 * Verified against OplusLauncher.apk (com.android.launcher):
 *   BubbleTextView.drawIcon(Canvas), getIconBounds(Rect), getIconVisible(),
 *   ItemInfo.getTargetPackage() via View.getTag().
 * Any error disables the module for that process and the stock icons draw as normal.
 */
public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "[GlassIcons] ";
    private static final String BTV = "com.android.launcher3.BubbleTextView";

    /** Edit this list to change which apps get glass tiles. */
    private static final Set<String> SELECTED = new HashSet<>(Arrays.asList(
        "com.android.contacts", "com.android.mms", "com.android.chrome", "com.oplus.camera",
        "com.android.settings", "com.coloros.gallery3d", "com.coloros.calculator", "com.coloros.weather2",
        "com.google.android.youtube", "com.whatsapp", "com.spotify.music", "org.telegram.messenger"));

    private static final Rect sBounds = new Rect();
    private static final RectF sRect = new RectF();
    private static final Path sPath = new Path();
    private static final Paint sBackdrop = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint sTint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint sFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint sRim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Paint sShine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final Matrix sMatrix = new Matrix();
    private static final int[] sLoc = new int[2];
    private static boolean sFailedOnce = false;

    private static Bitmap sBlurWall;
    private static boolean sWallTried = false;

    /** pkg -> {foreground Drawable, Integer tint}; value null = unusable, leave stock icon. */
    private static final Map<String, Object[]> sCache = new HashMap<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.launcher".equals(lpparam.packageName)) return;
        try {
            XposedHelpers.findAndHookMethod(BTV, lpparam.classLoader, "drawIcon", Canvas.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (sFailedOnce) return;
                        try {
                            if (drawTile((View) param.thisObject, (Canvas) param.args[0])) {
                                param.setResult(null); // we drew the icon, skip the stock one
                            }
                        } catch (Throwable t) {
                            sFailedOnce = true;
                            XposedBridge.log(TAG + "disabled after error:");
                            XposedBridge.log(t);
                        }
                    }
                });
            XposedBridge.log(TAG + "hooked BubbleTextView.drawIcon(Canvas), " + SELECTED.size() + " apps selected");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook failed:");
            XposedBridge.log(t);
        }
    }

    private static boolean drawTile(View v, Canvas c) throws Throwable {
        Object tag = v.getTag();
        if (tag == null) return false;
        Object pkgObj = XposedHelpers.callMethod(tag, "getTargetPackage");
        if (!(pkgObj instanceof String)) return false;
        String pkg = (String) pkgObj;
        if (!SELECTED.contains(pkg)) return false;

        Object vis = XposedHelpers.callMethod(v, "getIconVisible");
        if (vis instanceof Boolean && !((Boolean) vis)) return false;

        Object[] entry = loadEntry(v.getContext(), pkg);
        if (entry == null) return false;
        Drawable fg = (Drawable) entry[0];
        int tint = (Integer) entry[1];

        sBounds.setEmpty();
        XposedHelpers.callMethod(v, "getIconBounds", sBounds);
        int w = sBounds.width(), h = sBounds.height();
        if (w <= 0 || h <= 0) return false;

        float r = Math.min(w, h) * 0.2237f;
        float stroke = Math.max(1f, w * 0.018f);
        sRect.set(sBounds);
        sPath.reset();
        sPath.addRoundRect(sRect, r, r, Path.Direction.CW);

        c.save();
        c.clipPath(sPath);

        // 1. frosted backdrop: blurred wallpaper under this icon
        drawBackdrop(v, c, sRect);

        // 2. app-colour tint so the tile still reads as that app
        sTint.setColor(Color.argb(0x4D, Color.red(tint), Color.green(tint), Color.blue(tint)));
        c.drawRect(sRect, sTint);

        // 3. glass body: brighter at top
        sFill.setShader(new LinearGradient(0, sRect.top, 0, sRect.bottom,
            0x40FFFFFF, 0x12FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(sRect, sFill);

        // 4. the app's symbol (adaptive foreground layer is 108dp over a 72dp safe zone => 1.5x)
        float grow = w * 0.25f;
        fg.setBounds(Math.round(sBounds.left - grow), Math.round(sBounds.top - grow),
            Math.round(sBounds.right + grow), Math.round(sBounds.bottom + grow));
        fg.draw(c);

        // 5. specular sheen over the top ~45%
        sShine.setShader(new LinearGradient(0, sBounds.top, 0, sBounds.top + h * 0.45f,
            0x4DFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(sBounds.left, sBounds.top, sBounds.right, sBounds.top + h * 0.45f, sShine);
        c.restore();

        // 6. rim light: bright top-left, dim middle, brighter bottom-right
        sRim.setStyle(Paint.Style.STROKE);
        sRim.setStrokeWidth(stroke);
        sRim.setShader(new LinearGradient(sBounds.left, sBounds.top, sBounds.right, sBounds.bottom,
            new int[]{0xE6FFFFFF, 0x14FFFFFF, 0x14FFFFFF, 0xA6FFFFFF},
            new float[]{0f, 0.35f, 0.65f, 1f}, Shader.TileMode.CLAMP));
        float in = stroke / 2f;
        sRect.set(sBounds);
        sRect.inset(in, in);
        c.drawRoundRect(sRect, r - in, r - in, sRim);
        return true;
    }

    private static Object[] loadEntry(Context ctx, String pkg) {
        if (sCache.containsKey(pkg)) return sCache.get(pkg);
        Object[] result = null;
        try {
            PackageManager pm = ctx.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            Drawable icon = null;
            if (ai.icon != 0) {
                Resources res = pm.getResourcesForApplication(ai);
                icon = res.getDrawable(ai.icon, null);
            }
            if (icon == null) icon = pm.getApplicationIcon(pkg);
            XposedBridge.log(TAG + pkg + " icon class: " + (icon == null ? "null" : icon.getClass().getName()));
            if (icon instanceof AdaptiveIconDrawable) {
                AdaptiveIconDrawable a = (AdaptiveIconDrawable) icon;
                Drawable fg = a.getForeground();
                if (fg != null) {
                    result = new Object[]{fg.getConstantState() != null
                        ? fg.getConstantState().newDrawable(ctx.getResources()).mutate() : fg,
                        averageColor(a.getBackground())};
                }
            } else {
                XposedBridge.log(TAG + pkg + " is not adaptive, keeping stock icon");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "load failed for " + pkg + ":");
            XposedBridge.log(t);
        }
        sCache.put(pkg, result);
        return result;
    }

    private static int averageColor(Drawable bg) {
        if (bg == null) return Color.WHITE;
        try {
            Bitmap one = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(one);
            bg.setBounds(0, 0, 1, 1);
            bg.draw(cv);
            int p = one.getPixel(0, 0);
            return Color.rgb(Color.red(p), Color.green(p), Color.blue(p));
        } catch (Throwable t) {
            return Color.WHITE;
        }
    }

    private static void drawBackdrop(View v, Canvas c, RectF rect) {
        Bitmap wall = getBlurredWallpaper(v.getContext());
        if (wall == null) return;
        DisplayMetrics dm = v.getResources().getDisplayMetrics();
        float sw = dm.widthPixels, sh = dm.heightPixels;
        float scale = Math.max(sw / wall.getWidth(), sh / wall.getHeight());
        float tx = (sw - wall.getWidth() * scale) / 2f;
        float ty = (sh - wall.getHeight() * scale) / 2f;
        v.getLocationOnScreen(sLoc);
        BitmapShader shader = new BitmapShader(wall, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        sMatrix.setScale(scale, scale);
        sMatrix.postTranslate(tx - sLoc[0], ty - sLoc[1]);
        shader.setLocalMatrix(sMatrix);
        sBackdrop.setShader(shader);
        c.drawRect(rect, sBackdrop);
    }

    private static Bitmap getBlurredWallpaper(Context ctx) {
        if (sBlurWall != null || sWallTried) return sBlurWall;
        sWallTried = true;
        try {
            Drawable d = WallpaperManager.getInstance(ctx).getDrawable();
            if (d == null) { XposedBridge.log(TAG + "wallpaper drawable is null, no backdrop"); return null; }
            int w = 96, h = 208;
            Bitmap small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(small);
            int bw = Math.max(1, d.getIntrinsicWidth()), bh = Math.max(1, d.getIntrinsicHeight());
            float sc = Math.max((float) w / bw, (float) h / bh);
            cv.translate((w - bw * sc) / 2f, (h - bh * sc) / 2f);
            cv.scale(sc, sc);
            d.setBounds(0, 0, bw, bh);
            d.draw(cv);
            boxBlur(small, 3);
            boxBlur(small, 3);
            sBlurWall = small;
            XposedBridge.log(TAG + "blurred wallpaper ready " + w + "x" + h);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "wallpaper load failed, no backdrop:");
            XposedBridge.log(t);
        }
        return sBlurWall;
    }

    private static void boxBlur(Bitmap bmp, int rad) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] px = new int[w * h], tmp = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        blurPass(px, tmp, w, h, rad, true);
        blurPass(tmp, px, w, h, rad, false);
        bmp.setPixels(px, 0, w, 0, 0, w, h);
    }

    private static void blurPass(int[] src, int[] dst, int w, int h, int rad, boolean horiz) {
        int outer = horiz ? h : w, inner = horiz ? w : h;
        for (int o = 0; o < outer; o++) {
            for (int i = 0; i < inner; i++) {
                int a = 0, rr = 0, g = 0, b = 0, n = 0;
                for (int k = -rad; k <= rad; k++) {
                    int j = Math.min(inner - 1, Math.max(0, i + k));
                    int p = horiz ? src[o * w + j] : src[j * w + o];
                    a += p >>> 24; rr += (p >> 16) & 255; g += (p >> 8) & 255; b += p & 255; n++;
                }
                int q = ((a / n) << 24) | ((rr / n) << 16) | ((g / n) << 8) | (b / n);
                if (horiz) dst[o * w + i] = q; else dst[i * w + o] = q;
            }
        }
    }
}
