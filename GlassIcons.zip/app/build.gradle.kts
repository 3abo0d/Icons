plugins { id("com.android.application") }
android {
    namespace = "com.glassicons"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.glassicons"
        minSdk = 31
        targetSdk = 34
        versionCode = 3
        versionName = "0.3"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    buildTypes { release { isMinifyEnabled = false } }
}
dependencies { compileOnly(project(":xposed-stub")) }
