# Glass Icons v0.3
LSPosed module, scope: com.android.launcher (OplusLauncher, ColorOS 16).
Selected apps (edit SELECTED in MainHook.java) get a glass tile: blurred wallpaper slice, app-colour tint,
rim light, sheen, carrying only the app's own adaptive-icon foreground. Other apps are untouched.
Hook: BubbleTextView.drawIcon(Canvas). Stock drawing is skipped only for selected apps whose icon is adaptive.
Known: press/hover animation of the icon is not drawn for selected apps; wallpaper position is approximate.
Log: LSPosed log, search "[GlassIcons]" (shows each app's icon class and why one was skipped).
